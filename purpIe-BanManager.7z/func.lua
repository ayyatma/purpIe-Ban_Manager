---@meta _
---@diagnostic disable

function populateBoons()
    -- main gods + hermes
    for upgradeName, upgradeData in pairs(game.LootData) do
        if
            (upgradeData.GodLoot == true and
                upgradeData.PriorityUpgrades ~= nil and
                upgradeData.Traits ~= nil) or
            upgradeName == 'HermesUpgrade'
        then
            local godName = game.GetDisplayName({ Text = upgradeName })
            GodData[godName] = { Color = getColor(godName) }
            BoonData[godName] = {}
            ActiveBoons[godName] = {}
            local boons = {}
            for i, v in pairs(upgradeData.PriorityUpgrades) do
                local boon = { Name = game.GetDisplayName({ Text = v }), Key = v, Color = getColor(godName) }
                table.insert(boons, boon)
                ActiveBoons[godName][v] = true
                BoonData[v] = boon
                table.insert(BoonData[godName], boon)
            end
            for i, v in pairs(upgradeData.Traits) do
                local boon = { Key = v, Color = getColor(godName) }
                local boonName = game.GetDisplayName({ Text = v })
                if game.TraitData[v].IsDuoBoon then
                    boon.Duo = true
                elseif game.TraitData[v].IsElementalTrait then
                    boon.Elemental = true
                elseif game.TraitData[v].RarityLevels ~= nil and game.TraitData[v].RarityLevels.Legendary ~= nil then
                    boon.Legendary = true
                end

                boon.Name = boonName

                table.insert(boons, boon)
                ActiveBoons[godName][v] = true
                BoonData[v] = boon
                table.insert(BoonData[godName], boon)
            end

            Gods[upgradeName] = { Name = godName, Boons = boons }
        end
    end

    -- artemis
    local artemisBoons = {}
    ActiveBoons['Artemis'] = {}
    BoonData['Artemis'] = {}
    local artemisColor = getColor('Artemis')
    GodData['Artemis'] = { Color = artemisColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Artemis.NPC_Artemis_Field_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = artemisColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(artemisBoons, boon)
        ActiveBoons['Artemis'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Artemis'], boon)
    end
    Gods['ArtemisUpgrade'] = { Name = 'Artemis', Boons = artemisBoons }
    
    -- hades
    local hadesBoons = {}
    ActiveBoons['Hades'] = {}
    BoonData['Hades'] = {}
    local hadesColor = getColor('Hades')
    GodData['Hades'] = { Color = hadesColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Hades.NPC_Hades_Field_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = hadesColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(hadesBoons, boon)
        ActiveBoons['Hades'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Hades'], boon)
    end
    Gods['HadesUpgrade'] = { Name = 'Hades', Boons = hadesBoons }
    
    -- athena
    local athenaBoons = {}
    ActiveBoons['Athena'] = {}
    BoonData['Athena'] = {}
    local athenaColor = getColor('Athena')
    GodData['Athena'] = { Color = athenaColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Athena.NPC_Athena_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = athenaColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(athenaBoons, boon)
        ActiveBoons['Athena'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Athena'], boon)
    end
    Gods['AthenaUpgrade'] = { Name = 'Athena', Boons = athenaBoons }

    -- dionysus
    local dionysusBoons = {}
    ActiveBoons['Dionysus'] = {}
    BoonData['Dionysus'] = {}
    local dionysusColor = getColor('Dionysus')
    GodData['Dionysus'] = { Color = dionysusColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Dionysus.NPC_Dionysus_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = dionysusColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(dionysusBoons, boon)
        ActiveBoons['Dionysus'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Dionysus'], boon)
    end
    Gods['DionysusUpgrade'] = { Name = 'Dionysus', Boons = dionysusBoons }

    -- arachne
    local arachneBoons = {}
    ActiveBoons['Arachne'] = {}
    BoonData['Arachne'] = {}
    local arachneColor = getColor('Arachne')
    GodData['Arachne'] = { Color = arachneColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Arachne.NPC_Arachne_Field_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = arachneColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(arachneBoons, boon)
        ActiveBoons['Arachne'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Arachne'], boon)
    end
    Gods['ArachneUpgrade'] = { Name = 'Arachne', Boons = arachneBoons }

    -- narcissus
    local narcissusBoons = {}
    ActiveBoons['Narcissus'] = {}
    BoonData['Narcissus'] = {}
    local narcissusColor = getColor('Narcissus')
    GodData['Narcissus'] = { Color = narcissusColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Narcissus.NPC_Narcissus_Field_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = narcissusColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(narcissusBoons, boon)
        ActiveBoons['Narcissus'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Narcissus'], boon)
    end
    Gods['NarcissusUpgrade'] = { Name = 'Narcissus', Boons = narcissusBoons }

    -- echo
    local echoBoons = {}
    ActiveBoons['Echo'] = {}
    BoonData['Echo'] = {}
    local echoColor = getColor('Echo')
    GodData['Echo'] = { Color = echoColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Echo.NPC_Echo_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = echoColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(echoBoons, boon)
        ActiveBoons['Echo'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Echo'], boon)
    end
    Gods['EchoUpgrade'] = { Name = 'Echo', Boons = echoBoons }

    -- medea
    local medeaBoons = {}
    ActiveBoons['Medea'] = {}
    BoonData['Medea'] = {}
    local medeaColor = getColor('Medea')
    GodData['Medea'] = { Color = medeaColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Medea.NPC_Medea_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = medeaColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(medeaBoons, boon)
        ActiveBoons['Medea'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Medea'], boon)
    end
    Gods['MedeaUpgrade'] = { Name = 'Medea', Boons = medeaBoons }

    -- circe
    local circeBoons = {}
    ActiveBoons['Circe'] = {}
    BoonData['Circe'] = {}
    local circeColor = getColor('Circe')
    GodData['Circe'] = { Color = circeColor }
    for _, boonKey in ipairs(game.UnitSetData.NPC_Circe.NPC_Circe_01.Traits) do
        local boon = {
            Key = boonKey,
            Color = circeColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(circeBoons, boon)
        ActiveBoons['Circe'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Circe'], boon)
    end
    Gods['CirceUpgrade'] = { Name = 'Circe', Boons = circeBoons }

    -- axe upgrades
    local axeUpgrades = {}
    ActiveBoons['Axe Upgrades'] = {}
    BoonData['Axe Upgrades'] = {}
    local axeColor = getColor('Axe Upgrades')
    GodData['Axe Upgrades'] = { Color = axeColor }
    for _, boonKey in ipairs({ "AxeSpinSpeedTrait", "AxeChargedSpecialTrait", "AxeAttackRecoveryTrait", "AxeMassiveThirdStrikeTrait", "AxeThirdStrikeTrait", "AxeRangedWhirlwindTrait", "AxeFreeSpinTrait", "AxeArmorTrait", "AxeBlockEmpowerTrait", "AxeSecondStageTrait", "AxeDashAttackTrait", "AxeSturdyTrait", "AxeRallyFrenzyTrait", "AxeRallyFirstStrikeTrait" }) do
        local boon = {
            Key = boonKey,
            Color = axeColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(axeUpgrades, boon)
        ActiveBoons['Axe Upgrades'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Axe Upgrades'], boon)
    end
    Gods['AxeUpgrade'] = { Name = 'Axe Upgrades', Boons = axeUpgrades }

    -- dagger upgrades
    local daggerUpgrades = {}
    ActiveBoons['Dagger Upgrades'] = {}
    BoonData['Dagger Upgrades'] = {}
    local daggerColor = getColor('Dagger Upgrades')
    GodData['Dagger Upgrades'] = { Color = daggerColor }
    for _, boonKey in ipairs({ "DaggerBlinkAoETrait", "DaggerSpecialJumpTrait", "DaggerSpecialLineTrait", "DaggerRapidAttackTrait", "DaggerSpecialConsecutiveTrait", "DaggerBackstabTrait", "DaggerSpecialReturnTrait", "DaggerSpecialFanTrait", "DaggerAttackFinisherTrait", "DaggerFinalHitTrait", "DaggerChargeStageSkipTrait", "DaggerDashAttackTripleTrait", "DaggerTripleBuffTrait", "DaggerTripleRepeatWomboTrait", "DaggerTripleHomingSpecialTrait" }) do
        local boon = {
            Key = boonKey,
            Color = daggerColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(daggerUpgrades, boon)
        ActiveBoons['Dagger Upgrades'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Dagger Upgrades'], boon)
    end
    Gods['DaggerUpgrade'] = { Name = 'Dagger Upgrades', Boons = daggerUpgrades }

    -- staff upgrades
    local staffUpgrades = {}
    ActiveBoons['Staff Upgrades'] = {}
    BoonData['Staff Upgrades'] = {}
    local staffColor = getColor('Staff Upgrades')
    GodData['Staff Upgrades'] = { Color = staffColor }
    for _, boonKey in ipairs({ "StaffDoubleAttackTrait", "StaffLongAttackTrait", "StaffDashAttackTrait", "StaffTripleShotTrait", "StaffJumpSpecialTrait", "StaffExAoETrait", "StaffAttackRecoveryTrait", "StaffFastSpecialTrait", "StaffExHealTrait", "StaffSecondStageTrait", "StaffPowershotTrait", "StaffOneWayAttackTrait", "StaffRaiseDeadBigTrait", "StaffRaiseDeadDoubleTrait", "StaffLoneShadeRespawnTrait", "StaffLoneShadeRallyTrait" }) do
        local boon = {
            Key = boonKey,
            Color = staffColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(staffUpgrades, boon)
        ActiveBoons['Staff Upgrades'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Staff Upgrades'], boon)
    end
    Gods['StaffUpgrade'] = { Name = 'Staff Upgrades', Boons = staffUpgrades }

    -- torch upgrades
    local torchUpgrades = {}
    ActiveBoons['Torch Upgrades'] = {}
    BoonData['Torch Upgrades'] = {}
    local torchColor = getColor('Torch Upgrades')
    GodData['Torch Upgrades'] = { Color = torchColor }
    for _, boonKey in ipairs({ "TorchExSpecialCountTrait", "TorchSpecialSpeedTrait", "TorchAttackSpeedTrait", "TorchSpecialLineTrait", "TorchSpecialImpactTrait", "TorchMoveSpeedTrait", "TorchSplitAttackTrait", "TorchEnhancedAttackTrait", "TorchDiscountExAttackTrait", "TorchLongevityTrait", "TorchOrbitPointTrait", "TorchSpinAttackTrait", "TorchAutofireSprintTrait" }) do
        local boon = {
            Key = boonKey,
            Color = torchColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(torchUpgrades, boon)
        ActiveBoons['Torch Upgrades'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Torch Upgrades'], boon)
    end
    Gods['TorchUpgrade'] = { Name = 'Torch Upgrades', Boons = torchUpgrades }

    -- lob upgrades
    local lobUpgrades = {}
    ActiveBoons['Lob Upgrades'] = {}
    BoonData['Lob Upgrades'] = {}
    local lobColor = getColor('Lob Upgrades')
    GodData['Lob Upgrades'] = { Color = lobColor }
    for _, boonKey in ipairs({ "LobAmmoTrait", "LobAmmoMagnetismTrait", "LobRushArmorTrait", "LobSpreadShotTrait", "LobSpecialSpeedTrait", "LobSturdySpecialTrait", "LobOneSideTrait", "LobInOutSpecialExTrait", "LobStraightShotTrait", "LobPulseAmmoTrait", "LobPulseAmmoCollectTrait", "LobGrowthTrait", "LobGunOverheatTrait", "LobGunBounceTrait", "LobGunSpecialBounceTrait", "LobGunAttackRangeTrait", "LobGunAttackDoublerTrait" }) do
        local boon = {
            Key = boonKey,
            Color = lobColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(lobUpgrades, boon)
        ActiveBoons['Lob Upgrades'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Lob Upgrades'], boon)
    end
    Gods['LobUpgrade'] = { Name = 'Lob Upgrades', Boons = lobUpgrades }

    -- suit upgrades
    local suitUpgrades = {}
    ActiveBoons['Suit Upgrades'] = {}
    BoonData['Suit Upgrades'] = {}
    local suitColor = getColor('Suit Upgrades')
    GodData['Suit Upgrades'] = { Color = suitColor }
    for _, boonKey in ipairs({ "SuitArmorTrait", "SuitAttackSpeedTrait", "SuitAttackSizeTrait", "SuitAttackRangeTrait", "SuitFullChargeTrait", "SuitDashAttackTrait", "SuitSpecialJumpTrait", "SuitSpecialStartUpTrait", "SuitSpecialAutoTrait", "SuitSpecialBlockTrait", "SuitSpecialDiscountTrait", "SuitSpecialConsecutiveHitTrait", "SuitComboForwardRocketTrait", "SuitComboBlockBuffTrait", "SuitComboDoubleSpecialTrait", "SuitComboDashAttackTrait", "SuitPowershotTrait" }) do
        local boon = {
            Key = boonKey,
            Color = suitColor,
            Name = game.GetDisplayName({ Text = boonKey })
        }
        table.insert(suitUpgrades, boon)
        ActiveBoons['Suit Upgrades'][boonKey] = true
        BoonData[boonKey] = boon
        table.insert(BoonData['Suit Upgrades'], boon)
    end
    Gods['SuitUpgrade'] = { Name = 'Suit Upgrades', Boons = suitUpgrades }
end


-- this is just so it'll match with the colors i picked for dps meter
function getColor(name)
    local color = {}
    local inGameColor = game.Color.Black
    if name == 'Aphrodite' then
        inGameColor = game.Color.AphroditeDamage
    elseif name == 'Apollo' then
        inGameColor = game.Color.ApolloDamageLight
    elseif name == 'Ares' then
        inGameColor = game.Color.AresDamageLight
    elseif name == 'Athena' then
        inGameColor = game.Color.AthenaDamageLight
    elseif name == 'Demeter' then
        inGameColor = game.Color.DemeterDamage
    elseif name == 'Dionysus' then
        inGameColor = game.Color.DionysusDamage
    elseif name == 'Hera' then
        inGameColor = game.Color.HeraDamage
    elseif name == 'Hestia' then
        inGameColor = game.Color.HestiaDamageLight
    elseif name == 'Hephaestus' then
        inGameColor = game.Color.HephaestusDamage
    elseif name == 'Poseidon' then
        inGameColor = game.Color.PoseidonDamage
    elseif name == 'Zeus' then
        inGameColor = game.Color.ZeusDamageLight
    elseif name == 'Hermes' then
        inGameColor = game.Color.HermesVoice
    elseif name == 'Artemis' then
        inGameColor = game.Color.ArtemisDamage
    elseif name == 'Hades' then
        inGameColor = game.Color.HadesVoice
    elseif name == 'Arachne' then
        inGameColor = game.Color.ArachneVoice
    elseif name == 'Narcissus' then
        inGameColor = game.Color.NarcissusVoice
    elseif name == 'Echo' then
        inGameColor = game.Color.EchoVoice
    elseif name == 'Medea' then
        inGameColor = game.Color.MedeaVoice
    elseif name == 'Circe' then
        inGameColor = game.Color.CirceVoice
    elseif name == 'Axe Upgrades' then
        inGameColor = game.Color.Gold
    elseif name == 'Dagger Upgrades' then
        inGameColor = game.Color.Gold
    elseif name == 'Staff Upgrades' then
        inGameColor = game.Color.Gold
    elseif name == 'Torch Upgrades' then
        inGameColor = game.Color.Gold
    elseif name == 'Lob Upgrades' then
        inGameColor = game.Color.Gold
    elseif name == 'Suit Upgrades' then
        inGameColor = game.Color.Gold
    end
    color[1] = inGameColor[1] / 255
    color[2] = inGameColor[2] / 255
    color[3] = inGameColor[3] / 255
    color[4] = inGameColor[4] / 255
    return color
end
