---@meta _
---@diagnostic disable

local mods = rom.mods

---@module 'SGG_Modding-ENVY-auto'
mods['SGG_Modding-ENVY'].auto()

rom = rom

_PLUGIN = PLUGIN

---@module 'SGG_Modding-Hades2GameDef-Globals'
game = rom.game

---@module 'SGG_Modding-ModUtil'
modutil = mods['SGG_Modding-ModUtil']

---@module 'SGG_Modding-Chalk'
chalk = mods["SGG_Modding-Chalk"]
---@module 'SGG_Modding-ReLoad'
reload = mods['SGG_Modding-ReLoad']

---@module 'config'
config = chalk.auto()
public.config = config

local function on_ready()
    if config.enabled == false then return end

    Gods = {}
    GodData = {}
    ActiveBoons = {}
    BoonData = {}

    game.OnAnyLoad {function()
        -- Apply bans from config
        game.CurrentRun.BannedTraits = {}
        for godName, godTable in pairs(config) do
            if godName ~= "enabled" then
                if godName == "Daedalus" then
                    for weaponName, weaponTable in pairs(godTable) do
                        for boonKey, boonTable in pairs(weaponTable) do
                            if boonTable.Enabled == false then
                                game.CurrentRun.BannedTraits[boonKey] = true
                            end
                        end
                    end
                else
                    for boonKey, boonTable in pairs(godTable) do
                        if boonTable.Enabled == false then
                            game.CurrentRun.BannedTraits[boonKey] = true
                        end
                    end
                end
            end
        end
    end}
end

local function on_reload()
    import 'func.lua'
    import 'imgui.lua'

    populateBoons()
    -- Populate config with all boons set to true if not present
    for godName, boons in pairs(ActiveBoons) do
        for boonKey, _ in pairs(boons) do
            if godName == 'Axe Upgrades' then
                if config.Daedalus.Axe[boonKey] == nil then
                    config.Daedalus.Axe[boonKey] = { Enabled = true }
                end
            elseif godName == 'Dagger Upgrades' then
                if config.Daedalus.Dagger[boonKey] == nil then
                    config.Daedalus.Dagger[boonKey] = { Enabled = true }
                end
            elseif godName == 'Staff Upgrades' then
                if config.Daedalus.Staff[boonKey] == nil then
                    config.Daedalus.Staff[boonKey] = { Enabled = true }
                end
            elseif godName == 'Torch Upgrades' then
                if config.Daedalus.Torch[boonKey] == nil then
                    config.Daedalus.Torch[boonKey] = { Enabled = true }
                end
            elseif godName == 'Lob Upgrades' then
                if config.Daedalus.Lob[boonKey] == nil then
                    config.Daedalus.Lob[boonKey] = { Enabled = true }
                end
            elseif godName == 'Suit Upgrades' then
                if config.Daedalus.Suit[boonKey] == nil then
                    config.Daedalus.Suit[boonKey] = { Enabled = true }
                end
            else
                if config[godName][boonKey] == nil then
                    config[godName][boonKey] = { Enabled = true }
                end
            end
        end
    end
end

local loader = reload.auto_single()

modutil.once_loaded.game(function()
    loader.load(on_ready, on_reload)
end)
