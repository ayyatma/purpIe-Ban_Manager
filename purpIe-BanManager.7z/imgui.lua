---@meta _
---@diagnostic disable

rom.gui.add_imgui(function()
    if rom.ImGui.Begin("BanManager") then
        drawMenu()
        rom.ImGui.End()
    end
end)

rom.gui.add_to_menu_bar(function()
    if rom.ImGui.BeginMenu("Configure") then
        drawMenu()
        rom.ImGui.EndMenu()
    end
end)

function drawMenu()
    for godName, godTable in pairs(config) do
        if godName ~= "enabled" then
            if godName == "Daedalus" then
                for weaponName, weaponTable in pairs(godTable) do
                    local numBoons = 0
                    local numTrue = 0
                    for boonKey, boonTable in pairs(weaponTable) do
                        numBoons = numBoons + 1
                        if boonTable.Enabled then numTrue = numTrue + 1 end
                    end
                    local headerText = weaponName .. ' Upgrades ' .. numTrue .. '/' .. numBoons

                    local color = getColor(weaponName .. ' Upgrades')
                    rom.ImGui.PushStyleColor(rom.ImGuiCol.Header, color[1], color[2], color[3], 0.2)
                    rom.ImGui.PushStyleColor(rom.ImGuiCol.HeaderHovered, color[1], color[2], color[3], 0.5)
                    rom.ImGui.PushStyleColor(rom.ImGuiCol.HeaderActive, color[1], color[2], color[3], 0.7)
                    local open, notCollapsed = rom.ImGui.CollapsingHeader(headerText .. '###' .. weaponName)
                    rom.ImGui.PopStyleColor(3)
                    if open == true then
                        rom.ImGui.BeginChild(weaponName .. "Scrolling", 0, 440)
                        for boonKey, boonTable in pairs(weaponTable) do
                            local boonName = game.GetDisplayName({ Text = boonKey })
                            local value, checked = rom.ImGui.Checkbox(boonName, boonTable.Enabled)
                            if checked then
                                boonTable.Enabled = value
                            end
                            writeBoonRarity({ Key = boonKey, Name = boonName })
                        end
                        rom.ImGui.EndChild()
                    end
                end
            else
                local numBoons = 0
                local numTrue = 0
                for boonKey, boonTable in pairs(godTable) do
                    numBoons = numBoons + 1
                    if boonTable.Enabled then numTrue = numTrue + 1 end
                end
                local headerText = godName .. ' ' .. numTrue .. '/' .. numBoons

                local color = getColor(godName)
                rom.ImGui.PushStyleColor(rom.ImGuiCol.Header, color[1], color[2], color[3], 0.2)
                rom.ImGui.PushStyleColor(rom.ImGuiCol.HeaderHovered, color[1], color[2], color[3], 0.5)
                rom.ImGui.PushStyleColor(rom.ImGuiCol.HeaderActive, color[1], color[2], color[3], 0.7)
                local open, notCollapsed = rom.ImGui.CollapsingHeader(headerText .. '###' .. godName)
                rom.ImGui.PopStyleColor(3)
                if open == true then
                    rom.ImGui.BeginChild(godName .. "Scrolling", 0, 440)
                    for boonKey, boonTable in pairs(godTable) do
                        local boonName = game.GetDisplayName({ Text = boonKey })
                        local value, checked = rom.ImGui.Checkbox(boonName, boonTable.Enabled)
                        if checked then
                            boonTable.Enabled = value
                        end
                        writeBoonRarity({ Key = boonKey, Name = boonName })
                    end
                    rom.ImGui.EndChild()
                end
            end
        end
    end
    rom.ImGui.Spacing()
end

function writeBoonRarity(info)
    local traitData = game.TraitData[info.Key]
    if traitData then
        if traitData.IsDuoBoon then
            rom.ImGui.SameLine()
            rom.ImGui.TextColored(0.82, 1, 0.38, 1, '(D)')
        elseif traitData.RarityLevels and traitData.RarityLevels.Legendary then
            rom.ImGui.SameLine()
            rom.ImGui.TextColored(1, 0.56, 0, 1, '(L)')
        elseif traitData.IsElementalTrait then
            rom.ImGui.SameLine()
            rom.ImGui.TextColored(1, 0.29, 1, 1, '(I)')
        end
    end
end
