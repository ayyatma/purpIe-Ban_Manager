# Changelog

## [Unreleased]

## [0.2.0] - 2025-09-26

## [0.1.1] - 2025-02-20

## Added

- added Ares color

## [0.1.0] - 2024-10-17

## Added

- Athena and Dionysus boon lists

## [0.0.1] - 2024-06-19

## Added

- initial version

[unreleased]: https://github.com/The-Black-Lodge/JowdayBanManager/compare/0.2.0...HEAD
[0.2.0]: https://github.com/The-Black-Lodge/JowdayBanManager/compare/0.1.1...0.2.0
[0.1.1]: https://github.com/The-Black-Lodge/JowdayBanManager/compare/0.1.0...0.1.1
[0.1.0]: https://github.com/The-Black-Lodge/JowdayBanManager/compare/0.0.1...0.1.0
[0.0.1]: https://github.com/The-Black-Lodge/JowdayBanManager/compare/7b17e4d29f911f463529110a854a36c370db620c...0.0.1
